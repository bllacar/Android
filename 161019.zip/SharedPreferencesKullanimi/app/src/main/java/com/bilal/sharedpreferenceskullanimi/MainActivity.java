package com.bilal.sharedpreferenceskullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText etAd,etSoyad;
    Button btnKaydet,btnTemizle;
    SharedPreferences sp;
    SharedPreferences.Editor spe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etAd=findViewById(R.id.etAd);
        etSoyad=findViewById(R.id.etSoyad);
        btnKaydet=findViewById(R.id.btnKaydet);
        btnTemizle=findViewById(R.id.btnTemizle);

        sp= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        spe=sp.edit();

        // SharedPreferences'da kayıtlı deperleri getirdi
        if (!sp.getString("ad","").isEmpty()){
            etAd.setText(sp.getString("ad",""));
        }
        if (!sp.getString("soyad","").isEmpty()){
            etSoyad.setText(sp.getString("ad",""));
        }

        btnKaydet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // SharedPreferences'a veri kaydettik
                spe.putString("ad",etAd.getText().toString());
                spe.putString("soyad",etSoyad.getText().toString());
                spe.commit();
            }
        });
        btnTemizle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // SharedPreferences'da kayıtlı değerlerin hepsini sildik
                spe.clear();
                spe.commit();
            }
        });

    }
}
