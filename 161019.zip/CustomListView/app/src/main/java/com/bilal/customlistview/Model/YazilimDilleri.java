package com.bilal.customlistview.Model;

public class YazilimDilleri {

    private String isim;
    private String aciklama;
    private int resim;

    /*
    Kapsülleme İlkesi Kuralları

    1- Değişkenlerin private olarak tanımlanması
    2- Her değişken için get ve set metodlar üretilmesi
    3- Boş ve dolu constructor üretilmesi
    4- toString metodu üretilmesi*

     */

    public YazilimDilleri() {
    }

    public YazilimDilleri(String isim, String aciklama, int resim) {
        this.isim = isim;
        this.aciklama = aciklama;
        this.resim = resim;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getAciklama() {
        return aciklama;
    }

    public void setAciklama(String aciklama) {
        this.aciklama = aciklama;
    }

    public int getResim() {
        return resim;
    }

    public void setResim(int resim) {
        this.resim = resim;
    }
}
