package com.bilal.customlistview.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.bilal.customlistview.Adapter.YazilimDilleriAdapter;
import com.bilal.customlistview.Model.YazilimDilleri;
import com.bilal.customlistview.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    YazilimDilleriAdapter adapter;
    ArrayList<YazilimDilleri> yazilimDilleriArrayList=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        yazilimDilleriArrayList.add(new YazilimDilleri("Java","Java Açıklaması",R.drawable.java));
        yazilimDilleriArrayList.add(new YazilimDilleri("PHP","PHP Açıklaması",R.drawable.php));
        yazilimDilleriArrayList.add(new YazilimDilleri("Swift","Swift Açıklaması",R.drawable.swift));
        yazilimDilleriArrayList.add(new YazilimDilleri("Python","Python Açıklaması",R.drawable.python));
        yazilimDilleriArrayList.add(new YazilimDilleri("C#","C# Açıklaması",R.drawable.ic_launcher_background));
        yazilimDilleriArrayList.add(new YazilimDilleri("JavaScript","JavaScript Açıklaması",R.drawable.javascript));
        yazilimDilleriArrayList.add(new YazilimDilleri("Kotlin","Kotlin Açıklaması",R.drawable.kotlin));
        yazilimDilleriArrayList.add(new YazilimDilleri("C++","C++ Açıklaması",R.drawable.cplus));



        adapter =new YazilimDilleriAdapter(getApplicationContext(),yazilimDilleriArrayList);
        listView.setAdapter(adapter);
    }
}
