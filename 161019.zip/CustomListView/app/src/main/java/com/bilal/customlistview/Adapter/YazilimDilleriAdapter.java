package com.bilal.customlistview.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bilal.customlistview.R;
import com.bilal.customlistview.Model.YazilimDilleri;

import java.util.ArrayList;

public class YazilimDilleriAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<YazilimDilleri> arrayList = new ArrayList<>();

    public YazilimDilleriAdapter() {
    }

    public YazilimDilleriAdapter(Context context, ArrayList<YazilimDilleri> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        // ArrayList in eleman sayısını döner
        return arrayList.size();
    }

    @Override
    public Object getItem(int position) {
        // Tıkladığımız satırı döner
        return arrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        // Tıkladığımız satırın indisini döner
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        /*
         Her bir ListView satırının görüntüsünü oluşturmak için kullanılır.
         ayrıca satır içerisinde bulunan tüm nesne referanslarını getView içinde tanımlarız.
         getView metodu içerisinde layoutInflater bağlayıcısı kullanılmadan satır görüntüsü üretilmez.
         satır görüntüsü üretiminden çıktı alınamaz, yani program hata verir
         */

        View view = layoutInflater.inflate(R.layout.yazilimdilleri_satirgoruntusu, null);

        TextView tvBaslik=view.findViewById(R.id.tvBaslik);
        TextView tvAciklama=view.findViewById(R.id.tvAciklama);
        ImageView ivResim=view.findViewById(R.id.ivResim);

        tvBaslik.setText(arrayList.get(position).getIsim());
        tvAciklama.setText(arrayList.get(position).getAciklama());
        ivResim.setImageResource(arrayList.get(position).getResim());

        return view;
    }



}
