package com.bilal.milyoneroyunu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Button btnOyunaBasla, btnBasarilar, btnSkorlar, btnSatinAl, btnCikis;
    ImageView ivLogoMain, ivSound;
    int sayi = 0;
    SharedPreferences sp;
    SharedPreferences.Editor spe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.getSupportActionBar().hide();

        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        spe = sp.edit();

        btnOyunaBasla = findViewById(R.id.btnOyunaBasla);
        btnBasarilar = findViewById(R.id.btnBasarilar);
        btnSkorlar = findViewById(R.id.btnSkorlar);
        btnSatinAl = findViewById(R.id.btnSatinAl);
        btnCikis = findViewById(R.id.btnCikis);
        ivLogoMain = findViewById(R.id.ivLogoMain);
        ivSound = findViewById(R.id.ivSound);

        sayi = sp.getInt("sound", 1);
        if (sp.getInt("sound", 1) == 1) {
            ivSound.setImageResource(R.drawable.ic_on);
        } else if (sp.getInt("sound", 1) == 0) {
            ivSound.setImageResource(R.drawable.ic_off);
        }

        ivSound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sayi == 0) {//Ses açıksa
                    //Sesi kapat
                    sayi = 1;
                    ivSound.setImageResource(R.drawable.ic_on);
                } else if (sayi == 1) {//Ses kapalıysa
                    //Sesi aç
                    sayi = 0;
                    ivSound.setImageResource(R.drawable.ic_off);
                }
                spe.putInt("sound", sayi);
                spe.commit();
            }
        });

        btnOyunaBasla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        btnBasarilar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        btnSkorlar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        btnSatinAl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        btnCikis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
