package com.example.intentimage;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class DetayActivity extends AppCompatActivity {

    ImageView ivDetay;
    TextView tvDetay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detay);

        ivDetay = findViewById(R.id.ivDetay);
        tvDetay = findViewById(R.id.tvDetay);

        String takim=getIntent().getStringExtra("takım");
        int kulupId=getIntent().getIntExtra("kulüp",-1);
        tvDetay.setText(takim);

        if(kulupId!==-1){
            ivDetay.set
        }

        this.setTitle(takim);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        // Toolbara Geri Butonu Eklemek

        /*
        switch (takim){
            case "Galatasaray":
                //tvDetay.setText("Galatasaray");
                ivDetay.setImageResource(R.drawable.gs);
                break;
            case "Fenerbahçe":
                //tvDetay.setText("Fenerbahçe");
                ivDetay.setImageResource(R.drawable.fb);
                break;
            case "Beşiktaş":
                //tvDetay.setText("Beşiktaş");
                ivDetay.setImageResource(R.drawable.bjk);
                break;
            case "Trabzonspor":
                //tvDetay.setText("Trabzonspor");
                ivDetay.setImageResource(R.drawable.ts);
                break;
        }
         */
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish(); //Bulunduğum activity sayfasını kalıcı olarak kapattık.
        }
        return super.onOptionsItemSelected(item);
    }
}
