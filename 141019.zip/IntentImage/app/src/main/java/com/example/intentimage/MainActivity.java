package com.example.intentimage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    public void butonaTikla(View v) {

        Intent intent = new Intent(getApplicationContext(), DetayActivity.class);
        if (v.getId() == R.id.imGs) {
            intent.putExtra("takım", "Galatasaray");
            intent.putExtra("kulüp",R.drawable.gs);
        } else if (v.getId() == R.id.imFb) {
            intent.putExtra("takım", "Fenerbahçe");
            intent.putExtra("kulüp",R.drawable.fb);
        } else if (v.getId() == R.id.imBjk) {
            intent.putExtra("takım", "Beşiktaş");
            intent.putExtra("kulüp",R.drawable.bjk);
        } else if (v.getId() == R.id.imTs) {
            intent.putExtra("takım", "Trabzonspor");
            intent.putExtra("kulüp",R.drawable.ts);
        }
        startActivity(intent);
    }

    // ImageView imGs, imFb, imBjk, imTs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // imGs = findViewById(R.id.imGs);
        // imFb = findViewById(R.id.imFb);
        // imBjk = findViewById(R.id.imBjk);
        // imTs = findViewById(R.id.imTs);
    }
}
