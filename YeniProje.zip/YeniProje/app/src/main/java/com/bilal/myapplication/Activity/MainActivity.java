package com.bilal.myapplication.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import com.bilal.myapplication.Activity.AyarlarActivity;
import com.bilal.myapplication.R;

public class MainActivity extends AppCompatActivity {

    ListView kategoriler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.setTitle("Bulmacalar"); //Toolbarın başlığını değiştirir.
        kategoriler =findViewById(R.id.listViewKategoriler);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //Menü oluşturmak için kullanılır.
        getMenuInflater().inflate(R.menu.menu_main,menu); //menu_main.xml dosyasını toolabar aa gösterir.
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //Menu Item a tıklama olayını yakalamak için kullanılır.

        if (item.getItemId()==R.id.id_ayarlar){
            startActivity(new Intent(getApplicationContext(), AyarlarActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }
}
