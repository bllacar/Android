package com.bilal.myapplication.Model;

public class Kategori {
    private int id,kategoriSayi;
    private String emoji,baslik;

    public Kategori() {
    }

    public Kategori(int id, int kategoriSayi, String emoji, String baslik) {
        this.id = id;
        this.kategoriSayi = kategoriSayi;
        this.emoji = emoji;
        this.baslik = baslik;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getKategoriSayi() {
        return kategoriSayi;
    }

    public void setKategoriSayi(int kategoriSayi) {
        this.kategoriSayi = kategoriSayi;
    }

    public String getEmoji() {
        return emoji;
    }

    public void setEmoji(String emoji) {
        this.emoji = emoji;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }
}
