package com.example.deneme2.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

import com.example.deneme2.Model.Bilmece;
import com.example.deneme2.Model.Kategori;
import com.example.deneme2.R;

import java.util.ArrayList;

public class BilmecelerActivity extends AppCompatActivity {

    TextView tvPaylas, tvRastgele, tvFavori, tvBilmeceSoru, tvOnceki, tvYanit, tvSonraki;
    Button btnIlerle;

    ArrayList<Bilmece> bilmeceler = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bilmeceler);

        Kategori kategori = (Kategori) getIntent().getSerializableExtra("kategori");
        this.setTitle(kategori.getBaslik());

        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvPaylas = findViewById(R.id.tvPaylas);
        tvRastgele = findViewById(R.id.tvRastgele);
        tvFavori = findViewById(R.id.tvFavori);
        tvBilmeceSoru = findViewById(R.id.tvBilmeceSoru);
        tvOnceki = findViewById(R.id.tvOnceki);
        tvYanit = findViewById(R.id.tvYanit);
        tvSonraki = findViewById(R.id.tvSonraki);
        btnIlerle = findViewById(R.id.btnIlerle);

        for (int i = 0; i < 20; i++) {
            bilmeceler.add(new Bilmece(i, kategori.getId(), "Başlık " + i, "Yanıt " + i));
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) ;
        {
            finish(); //Bulunduğum sayfayı kapattım
        }
        return super.onOptionsItemSelected(item);
    }
}
