package com.example.deneme2.Model;

import java.io.Serializable;

public class Kategori implements Serializable {
    private int id;
    private String emoji;
    private String baslik;
    private int kategoriSayi;

    public Kategori() {
    }

    public Kategori(int id, String emoji, String baslik, int kategoriSayi) {
        this.id = id;
        this.emoji = emoji;
        this.baslik = baslik;
        this.kategoriSayi = kategoriSayi;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmoji() {
        return emoji;
    }

    public void setEmoji(String emoji) {
        this.emoji = emoji;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public int getKategoriSayi() {
        return kategoriSayi;
    }

    public void setKategoriSayi(int kategoriSayi) {
        this.kategoriSayi = kategoriSayi;
    }
}
