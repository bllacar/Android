package com.example.deneme2.Adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import com.example.deneme2.Activity.BilmecelerActivity;
import com.example.deneme2.Model.Bilmece;
import com.example.deneme2.R;

import java.util.ArrayList;

public class BilmeceAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<Bilmece> bilmeceler;

    public BilmeceAdapter() {
    }

    public BilmeceAdapter(Context context, ArrayList<Bilmece> bilmeceler) {
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.bilmeceler = bilmeceler;
    }

    @Override
    public int getCount() {
        return bilmeceler.size();
    }

    @Override
    public Bilmece getItem(int position) {
        return bilmeceler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = layoutInflater.inflate(R.layout.bilmece_satirgoruntusu, null);

        TextView tv_BilmeceBaslik = view.findViewById(R.id.tv_BilmeceBaslik);
        LinearLayout linearPaylas = view.findViewById(R.id.linearPaylas);
        LinearLayout linearFavori = view.findViewById(R.id.linearFavori);
        LinearLayout linearCevabiGoster = view.findViewById(R.id.linearCevabiGoster);

        tv_BilmeceBaslik.setText(bilmeceler.get(position).getBilmeceBaslik());

        linearPaylas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT,"TEXT");
                context.startActivity(i);
            }
        });

        linearFavori.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        linearCevabiGoster.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder adb=new AlertDialog.Builder(context);
                adb.setTitle(bilmeceler.get(position).getBilmeceBaslik());
                adb.setMessage("Cevap: "+bilmeceler.get(position).getBilmeceYanit());
                adb.setCancelable(false);
                adb.setPositiveButton("KAPAT", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                adb.create();
                adb.show();

            }
        });

        return view;
    }
}
