package com.example.deneme2.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import com.example.deneme2.Adapter.BilmeceAdapter;
import com.example.deneme2.Model.Bilmece;
import com.example.deneme2.Model.Kategori;
import com.example.deneme2.R;

import java.util.ArrayList;

public class BilmecelerListActivity extends AppCompatActivity {

    ListView listViewBilmeceler;
    ArrayList<Bilmece> bilmeceler = new ArrayList<>();
    BilmeceAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bilmeceler_list);

        Kategori kategori = (Kategori) getIntent().getSerializableExtra("kategori");
        this.setTitle(kategori.getBaslik());
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        listViewBilmeceler = findViewById(R.id.listViewBilmeceler);

        for (int i = 0; i < 20; i++) {
            bilmeceler.add(new Bilmece(i, kategori.getId(), "Başlık " + i, "Yanıt " + i));
        }

        adapter=new BilmeceAdapter(BilmecelerListActivity.this,bilmeceler);
        listViewBilmeceler.setAdapter(adapter);
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) ;
        {
            finish(); //Bulunduğum sayfayı kapattım
        }
        return super.onOptionsItemSelected(item);
    }
}
