package com.example.deneme2.Model;

import java.io.Serializable;

public class Bilmece implements Serializable {
    private int bilmeceId;
    private int kategoriId;
    private String bilmeceBaslik;
    private String bilmeceYanit;

    public Bilmece() {
    }

    public Bilmece(int bilmeceId, int kategoriId, String bilmeceBaslik, String bilmeceYanit) {
        this.bilmeceId = bilmeceId;
        this.kategoriId = kategoriId;
        this.bilmeceBaslik = bilmeceBaslik;
        this.bilmeceYanit = bilmeceYanit;
    }

    public int getBilmeceId() {
        return bilmeceId;
    }

    public void setBilmeceId(int bilmeceId) {
        this.bilmeceId = bilmeceId;
    }

    public int getKategoriId() {
        return kategoriId;
    }

    public void setKategoriId(int kategoriId) {
        this.kategoriId = kategoriId;
    }

    public String getBilmeceBaslik() {
        return bilmeceBaslik;
    }

    public void setBilmeceBaslik(String bilmeceBaslik) {
        this.bilmeceBaslik = bilmeceBaslik;
    }

    public String getBilmeceYanit() {
        return bilmeceYanit;
    }

    public void setBilmeceYanit(String bilmeceYanit) {
        this.bilmeceYanit = bilmeceYanit;
    }
}
