package com.example.deneme2.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.deneme2.Model.Bilmece;
import com.example.deneme2.Model.Kategori;
import com.example.deneme2.R;

import java.util.ArrayList;
import java.util.Random;

public class BilmecelerActivity extends AppCompatActivity {

    TextView tvPaylas, tvRastgele, tvFavori, tvBilmeceSoru, tvOnceki, tvYanit, tvSonraki;
    Button btnIlerle;
    int soruIndex = 0;

    ArrayList<Bilmece> bilmeceler = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bilmeceler);

        Kategori kategori = (Kategori) getIntent().getSerializableExtra("kategori");
        this.setTitle(kategori.getBaslik());

        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvPaylas = findViewById(R.id.tvPaylas);
        tvRastgele = findViewById(R.id.tvRastgele);
        tvFavori = findViewById(R.id.tvFavori);
        tvBilmeceSoru = findViewById(R.id.tvBilmeceSoru);
        tvOnceki = findViewById(R.id.tvOnceki);
        tvYanit = findViewById(R.id.tvYanit);
        tvSonraki = findViewById(R.id.tvSonraki);
        btnIlerle = findViewById(R.id.btnIlerle);

        for (int i = 0; i < 20; i++) {
            bilmeceler.add(new Bilmece(i, kategori.getId(), "Başlık " + i, "Yanıt " + i));
        }

        btnIlerle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (soruIndex<bilmeceler.size()-1){
                    soruIndex++;
                }
                tvBilmeceSoru.setText(bilmeceler.get(soruIndex).getBilmeceBaslik());
            }
        });

        tvBilmeceSoru.setText(bilmeceler.get(soruIndex).getBilmeceBaslik());

        tvOnceki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (soruIndex!=0){
                    soruIndex--;
                }
                tvBilmeceSoru.setText(bilmeceler.get(soruIndex).getBilmeceBaslik());
            }
        });

        tvYanit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder adb=new AlertDialog.Builder(BilmecelerActivity.this);
                adb.setTitle(bilmeceler.get(soruIndex).getBilmeceBaslik());
                adb.setMessage("Cevap: "+bilmeceler.get(soruIndex).getBilmeceYanit());
                adb.setCancelable(false);
                adb.setPositiveButton("KAPAT", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                adb.create();
                adb.show();
            }
        });

        tvSonraki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (soruIndex<bilmeceler.size()-1){
                    soruIndex++;
                }
                tvBilmeceSoru.setText(bilmeceler.get(soruIndex).getBilmeceBaslik());
            }
        });

        tvRastgele.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random rnd =new Random();
                int rastgeleIndex=rnd.nextInt(bilmeceler.size());
                soruIndex=rastgeleIndex;
                tvBilmeceSoru.setText(bilmeceler.get(soruIndex).getBilmeceBaslik());
            }
        });

        tvPaylas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT,"TEXT");
                startActivity(i);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) ;
        {
            finish(); //Bulunduğum sayfayı kapattım
        }
        return super.onOptionsItemSelected(item);
    }
}
