package com.bilal.scrollviewkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.LinearGradient;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    public void onClick(View v) {
        Toast.makeText(getApplicationContext(),"Butona tıklandı",Toast.LENGTH_LONG).show();
    }

    LinearLayout linearLayout;

    // PROGRAMATİK OLARAK NESNE ÜRETME

    public void nesneUret(String nesne, String nesneAdi) {

        if ("textview".equals(nesne)) {
            TextView tv=new TextView(getApplicationContext());
            tv.setText(""+nesneAdi);
            linearLayout.addView(tv);
        }else if ("button".equals(nesne)) {
            Button btn=new Button(getApplicationContext());
            btn.setText(""+nesneAdi);
            linearLayout.addView(btn);
        } else if ("checkbox".equals(nesne)) {
            CheckBox chk=new CheckBox(getApplicationContext());
           chk.setText(""+nesneAdi);
            linearLayout.addView(chk);
        } else if ("edittext".equals(nesne)) {
            EditText et=new EditText(getApplicationContext());
            et.setText(""+nesneAdi);
            linearLayout.addView(et);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linearLayout = findViewById(R.id.linearLayout);

        nesneUret("button","Buton1");
        nesneUret("edittext","Yazı1");
        nesneUret("button","Buton2");
        nesneUret("edittext","Yazı2");
        nesneUret("button","Buton3");
        nesneUret("edittext","Yazı3");
        nesneUret("button","Buton4");
        nesneUret("edittext","Yazı4");

    }


}
