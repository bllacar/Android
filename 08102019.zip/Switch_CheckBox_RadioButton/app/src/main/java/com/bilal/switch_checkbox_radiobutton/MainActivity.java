package com.bilal.switch_checkbox_radiobutton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    CheckBox chk;
    ToggleButton tb;
    Switch sw;
    RadioButton rbErkek, rbKadin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chk = findViewById(R.id.checkBox);
        tb = findViewById(R.id.toggleButton);
        sw = findViewById(R.id.switch1);
        rbErkek = findViewById(R.id.erkek);
        rbKadin = findViewById(R.id.kadin);

        chk.setChecked(true);
        tb.setChecked(true);
        sw.setChecked(true);

        chk.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Log.d("durum", "ChechBox aktif edildi");
                }else {
                    Log.d("durum", "ChechBox pasif edildi");
                }
            }
        });
        tb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Log.d("durum", "ToggleButton aktif edildi");
                }else {
                    Log.d("durum", "ToggleButton pasif edildi");
                }
            }
        });
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Log.d("durum", "Switch aktif edildi");
                }else {
                    Log.d("durum", "Switch pasif edildi");
                }
            }
        });
        rbErkek.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Log.d("durum", "Erkek seçildi");
                }else {
                    Log.d("durum", "Erkek seçimi iptal edildi");
                }
            }
        });
        rbKadin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Log.d("durum", "Kadın seçildi");
                }else {
                    Log.d("durum", "Kadın seçimi iptal edildi");
                }
            }
        });
    }
}
